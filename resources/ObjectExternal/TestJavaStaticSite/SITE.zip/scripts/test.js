window.onload = function() {
	document.getElementById("test").innerHTML = "It works!";
};
